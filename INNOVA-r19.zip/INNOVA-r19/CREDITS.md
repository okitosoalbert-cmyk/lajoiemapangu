# Crédits INNOVA

- Lajoie [nom complet à confirmer] — documents de départ et plan de travail fournis à l’équipe.
- Okitosomba Albert Theia — développement et intégration du prototype, notamment la borne tactile, la voix, la recherche de cours et l’orientation sur le campus, avec assistance de Codex.
- [Autres contributions, s’il y a lieu] — préciser les personnes et leurs contributions.

Les noms, rôles et mentions d’assistance doivent être validés avant la publication. Reprendre ces crédits sur la fiche MakeRepo et dans le rapport.
