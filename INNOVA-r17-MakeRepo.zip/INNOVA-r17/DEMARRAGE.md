# Reproduire le prototype sous Windows

1. Installe Python 3.11 ou plus récent et Chrome.
2. Extrais le ZIP au complet et double-clique sur `Lancer-INNOVA.bat`. Le lanceur installe les dépendances et ouvre la borne dans le navigateur.
3. Pour refaire une démonstration, choisis un emplacement de borne, par exemple le CRX, puis demande « Comment aller à Fauteux ? ». Vérifie le pavillon, le bouton Trajet et le QR.
4. En option, configure **ta propre clé Gemini** avec `Configurer-Gemini.bat`. La clé reste dans le profil Windows. Tu peux tester la connexion avec `Tester-Gemini.bat`. Le plan local et la navigation de base fonctionnent sans clé. L’appel à l’horaire public, les vues Google et Gemini nécessitent Internet.
5. Pour tester la dictée et la présence, active le mode automatique et autorise le micro et la caméra dans Chrome. Depuis la borne, tu peux aussi utiliser le clavier tactile.

Voir `README.md` pour le détail des fonctionnalités et `DROITS-ET-SOURCES.md` pour les sources.
