# Droits et sources

## Éléments propres au projet

Dossier préparé à partir d’INNOVA r17, commit `0eb58c58e0686ede6c1b179d22ce071dda983299`. Confirmer les titulaires et la licence applicable au code et aux documents avant le dépôt public. Ce fichier n’accorde aucune licence supplémentaire. Les conditions existantes applicables aux éléments tiers continuent de s’appliquer.

## Sources tierces

- **OpenStreetMap** — les fichiers `static/campus-map.json` et `static/pedestrian-map.json` comprennent des données et des géométries dérivées d’OpenStreetMap. Les données OSM sont sous licence ODbL 1.0, © les contributeurs d’OpenStreetMap. Conserver cette mention et vérifier les obligations de redistribution et de mise à disposition des données dérivées. [Attribution et licence OSM](https://www.openstreetmap.org/copyright)
- **Université d’Ottawa** — les fiches du campus et l’index des liens citent les pages publiques d’uOttawa. La recherche de cours consulte l’horaire public. Vérifier les droits de publication des documents, logos ou visuels institutionnels ajoutés à la remise.
- **Google** — Gemini, Maps, Earth et Street View sont des services externes soumis à leurs conditions. Ce dossier contient des liens vers les vues Google, ainsi que du code client pour appeler les API avec une clé fournie par l’utilisateur.
- **Dépendances Python** — Flask, qrcode, Pillow, Beautiful Soup et tzdata s’installent via `requirements.txt`. Leurs licences restent celles de leurs éditeurs respectifs.
